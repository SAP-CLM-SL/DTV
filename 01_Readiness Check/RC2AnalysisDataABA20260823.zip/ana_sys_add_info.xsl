<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:asx="http://www.sap.com/abapxml">

  <xsl:output method="html"/>

  <xsl:template match="/">
    <html>
      <head>
        <title>SAP Readiness Check</title>
        <link rel="stylesheet" type="text/css" href="fui-site.css"/>
      </head>
      <body>
            <article class="fd-page">
              <header class="fd-page__header">
                <div class="fd-action-bar">
                  <div class="fd-action-bar__header">
                    <h1 class="fd-action-bar__title">
                      SAP Readiness Check - system information
                    </h1>


                  </div>

                </div>
                <p class="fd-action-bar__description">

                   The <b>ana_sys_add_info.xml</b> collects the technical system
                   information, for example operation system, database,
                   kernel, unicode, installation number, list of installed
                   product version and software components.
                 </p>
                <table class="fd-table">
                  <tr>
                    <th>Key</th>
                    <th>Value</th>
                  </tr>

                  <xsl:for-each select="/asx:abap/asx:values/HEADER_DATA/item">

                    <tr>
                      <td><xsl:value-of select="KEY"/></td>
                      <td><xsl:value-of select="VALUE"/></td>
                    </tr>
                  </xsl:for-each>

                </table>

                <p class="fd-action-bar__description">

                   Below is the list of all installed product versions
                 </p>
                <table class="fd-table">
                  <tr>
                    <th>PPMS ID</th>
                    <th>Product</th>
                    <th>Version</th>
                    <th>Vendor</th>
                    <th>Description</th>
                  </tr>

                  <xsl:for-each select="/asx:abap/asx:values/PRODUCT_VERSION/INSTSWPROD">

                    <tr>
                      <td><xsl:value-of select="ID"/></td>
                      <td><xsl:value-of select="NAME"/></td>
                      <td><xsl:value-of select="VERSION"/></td>
                      <td><xsl:value-of select="VENDOR"/></td>
                      <td><xsl:value-of select="DESCRIPT"/></td>
                    </tr>
                  </xsl:for-each>

                </table>

                <p class="fd-action-bar__description">

                   Below is the list of all installed software components and their support package levels
                 </p>
                <table class="fd-table">
                  <tr>
                    <th>Software Component</th>
                    <th>Version</th>
                    <th>Support Package Level</th>
                  </tr>

                  <xsl:for-each select="/asx:abap/asx:values/SW_COMPONENT/item">

                    <tr>
                      <td><xsl:value-of select="COMPONENT"/></td>
                      <td><xsl:value-of select="RELEASE"/></td>
                      <td><xsl:value-of select="EXTRELEASE"/></td>
                    </tr>
                  </xsl:for-each>

                </table>

                <p class="fd-action-bar__description">

                   Below is the list of all completely implemented SAP Notes in the system
                 </p>
                <table class="fd-table">
                  <tr>
                    <th>SAP Note</th>
                    <th>Version</th>
                  </tr>

                  <xsl:for-each select="/asx:abap/asx:values/IMPLEMENTED_NOTE/item">

                    <tr>
                      <td><xsl:value-of select="NUMBER"/></td>
                      <td><xsl:value-of select="VERSION"/></td>
                    </tr>
                  </xsl:for-each>

                </table>
              </header>
            </article>


      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
