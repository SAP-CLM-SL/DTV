<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:asx="http://www.sap.com/abapxml">

  <xsl:output method="html"/>

  <xsl:template match="/">
    <html>
      <head>
        <title>SAP Readiness Check</title>
        <link rel="stylesheet" type="text/css" href="fui-site.css"/>
      </head>
      <body>
            <article class="fd-page">
              <header class="fd-page__header">
                <div class="fd-action-bar">
                  <div class="fd-action-bar__header">
                    <h1 class="fd-action-bar__title">
                      SAP Readiness Check - HANA sizing
                    </h1>


                  </div>

                </div>
                <p class="fd-action-bar__description">

                   The <b>hana_sizing.xml</b> collects what you could see in
                   report /SDF/HDB_SIZING and top 1000 tables
                 </p>

                 <table class="fd-table">
                   <tr>
                     <th>Summary Information</th>
                     <th></th>
                   </tr>

                   <tr>
                     <td>Executed Date</td>
                    <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/CRDATE"/></td>
                  </tr>
                  <tr>
                    <td>Executed Time</td>
                   <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/CRTIME"/></td>
                 </tr>
                 <tr>
                   <td>Report Name</td>
                  <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/REPORT_NAME"/></td>
                </tr>
                <tr>
                  <td>HANA Sizing report version</td>
                 <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/REPORT_VERSION"/></td>
               </tr>
               <tr>
                 <td>Central Database System</td>
                <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/DB_VENDOR"/></td>
              </tr>
              <tr>
                <td>Database release</td>
               <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/DB_RELEASE"/></td>
             </tr>
             <tr>
               <td>Variant used for HANA sizing</td>
              <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/SIZING_VARIANT"/></td>
            </tr>
            <tr>
              <td>Count of tables analyzed successfully</td>
             <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/NB_TABLES"/></td>
           </tr>
           <tr>
             <td>Number of errors during Sizing run</td>
            <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/NB_ERRORS"/></td>
          </tr>
          <tr>
            <td>List of errors that occured during sizing run</td>
           <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/ERROR_LIST"/></td>
         </tr>
         <tr>
           <td>Uncompressed size</td>
          <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/ABAP_SIZE"/></td>
        </tr>
        <tr>
          <td>Size of current database</td>
         <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/ANYDB_SIZE"/></td>
       </tr>
       <tr>
         <td>Estimated size of the HANA Row Store</td>
        <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/RS_SIZE"/></td>
      </tr>
      <tr>
        <td>Estimated size of the HANA Column Store on master node</td>
       <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/CS_SIZE_MASTER"/></td>
     </tr>
     <tr>
       <td>Estimated size of the HANA Column Store on Slave nodes</td>
      <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/CS_SIZE_SLAVE"/></td>
    </tr>
    <tr>
      <td>Number of slaves</td>
     <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/NB_SLAVES"/></td>
   </tr>
   <tr>
     <td>Estimated size of hybrid lobs in HANA row store</td>
    <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/RS_HL_SIZE"/></td>
  </tr>
  <tr>
    <td>Estimated size of hybrid lobs in HANA Column store</td>
   <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/CS_HL_SIZE"/></td>
 </tr>
 <tr>
   <td>Estimated HANA data volume size</td>
  <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/DISK_SIZE"/></td>
</tr>
<tr>
  <td>Estimated memory size</td>
 <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/TOTAL_SIZING1"/></td>
</tr>
<tr>
  <td>Estimated memory size</td>
 <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/TOTAL_SIZING2"/></td>
</tr>
<tr>
  <td>Estimated memory size</td>
 <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/TOTAL_SIZING3"/></td>
</tr>
<tr>
  <td>Estimated memory size</td>
 <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/TOTAL_SIZING4"/></td>
</tr>
<tr>
  <td>Estimated memory size</td>
 <td><xsl:value-of select="/asx:abap/asx:values/SUMSIZE/TOTAL_SIZING5"/></td>
</tr>

                 </table>

                 <table class="fd-table">
                   <tr>
                     <th>Key</th>
                     <th>Value</th>
                   </tr>

                   <xsl:for-each select="/asx:abap/asx:values/SUBTOTOAL/item">
                     <tr>
                       <td><xsl:value-of select="SUB_TOAL_NAME"/></td>
                       <td><xsl:value-of select="SUB_TOAL"/></td>
                     </tr>
                   </xsl:for-each>

                 </table>

                <table class="fd-table">
                  <tr>
                    <th>Table Name</th>
                    <th>Partition ID</th>
                    <th>Table Type</th>
                    <th>Row/Column Store indicator</th>
                    <th>Table size as reported by source DB</th>
                    <th>Extrapolated table size in ABAP</th>
                    <th>Estimated HANA size</th>
                    <th>Total number of records</th>
                    <th>Number of records in sample set</th>
                    <th>Calculated size of sampled records</th>
                    <th>Calculated size of LOBs in sampled records</th>
                    <th>Extrapolated size of data in table</th>
                    <th>Extrapolated size of data in table after clean-up</th>
                    <th>Extrapolated size of LOBs in table</th>
                    <th>Calculated size of HANA indexes (row store tables)</th>
                    <th>Object Name in Object Directory</th>
                    <th>Object Type</th>
                  </tr>

                  <xsl:for-each select="/asx:abap/asx:values/SIZING/item">

                    <tr>
                      <td><xsl:value-of select="TABLE_NAME"/></td>
                      <td><xsl:value-of select="PART_ID"/></td>
                      <td><xsl:value-of select="TAB_TYPE"/></td>
                      <td><xsl:value-of select="STORE_TYPE"/></td>
                      <td><xsl:value-of select="SRC_DB_SIZE"/></td>
                      <td><xsl:value-of select="ABAP_SIZE"/></td>
                      <td><xsl:value-of select="HANA_SIZE"/></td>
                      <td><xsl:value-of select="RECORD_COUNT"/></td>
                      <td><xsl:value-of select="RECORDS_SAMPLED"/></td>
                      <td><xsl:value-of select="DATA_SIZE_SAMPLE"/></td>
                      <td><xsl:value-of select="LOB_SIZE_SAMPLED"/></td>
                      <td><xsl:value-of select="DATA_SIZE"/></td>
                      <td><xsl:value-of select="OPT_SIZE"/></td>
                      <td><xsl:value-of select="LOB_SIZE"/></td>
                      <td><xsl:value-of select="HANA_INDEX_SIZE"/></td>
                      <td><xsl:value-of select="OBJECT_NAME"/></td>
                      <td><xsl:value-of select="TLOGO"/></td>
                    </tr>
                  </xsl:for-each>

                </table>



              </header>
            </article>


      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
