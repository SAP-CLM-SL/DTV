<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:asx="http://www.sap.com/abapxml">

  <xsl:output method="html"/>

  <xsl:template match="/">
    <html>
      <head>
        <title>SAP Readiness Check</title>
        <link rel="stylesheet" type="text/css" href="fui-site.css"/>
      </head>
      <body>
            <article class="fd-page">
              <header class="fd-page__header">
                <div class="fd-action-bar">
                  <div class="fd-action-bar__header">
                    <h1 class="fd-action-bar__title">
                      SAP Readiness Check - Simplification Item consistency check result
                    </h1>

                  </div>

                </div>
                <p class="fd-action-bar__description">

                                     The <b>sitem_consistency.xml</b> collects the data Consistency
                                     result from the simplification item check (/SDF/RC_START_CHECK)
                                     based on S/4HANA stack <xsl:value-of select="/asx:abap/asx:values/CONVERSION_TARGET_STACK"/>
                 </p>
                 <br />
                 <p class="fd-action-bar__description">
                   1. Check Information
                 </p>
                 <table class="fd-table">


                   <xsl:for-each select="/asx:abap/asx:values/SITEM_CONSIS_CHK_HDR_INFO/item">
                     <tr>
                       <td><xsl:value-of select="."/></td>
                     </tr>
                   </xsl:for-each>

                 </table>

                 <p class="fd-action-bar__description">
                   2. Check result: Only the first 10 results are present and others are similar. The column CHK_CLAS_RESULT_XSTR
                   contains the raw data, which cannot be display here. It is the same as /SDF/RC_START_CHECK ->
                   Display Last Check Result -> Display Consistency Check Log
                 </p>
                <table class="fd-table">
                  <tr>
                    <th>Item Name</th>
                    <th>Check Class</th>
                    <th>SAP Note</th>
                    <th>Return Code</th>
                    <th>Skippable Error</th>
                    <th>Skipped Status</th>
                    <th>Started Time</th>
                    <th>End Time</th>
                    <th>Runtime</th>
                    <th>Head Info</th>

                  </tr>

                  <xsl:for-each select="/asx:abap/asx:values/SITEM_CONSIS_CHECK_RESULT/item[not(position() &gt;10)]">
                    <tr>
                      <td><xsl:value-of select="SITEM_ID"/></td>
                      <td><xsl:value-of select="CHECK_CLASS"/></td>
                      <td><xsl:value-of select="SAP_NOTE"/></td>
                      <td><xsl:value-of select="RETURN_CODE"/></td>
                      <td><xsl:value-of select="SKIPPABLE_ERROR"/></td>
                      <td><xsl:value-of select="SKIP_STATUS"/></td>
                      <td><xsl:value-of select="START_TIME"/></td>
                      <td><xsl:value-of select="END_TIME"/></td>
                      <td><xsl:value-of select="RUNNING_TIME_IN_SECONDS"/></td>
                      <td><xsl:call-template name="HEADER_INFO_TABLE"/></td>
                    </tr>
                  </xsl:for-each>

                </table>
              </header>
            </article>


      </body>
    </html>
  </xsl:template>
  <xsl:template match="HEADER_INFO_TABLE" name="HEADER_INFO_TABLE" mode="HEADER_INFO_TABLE">
		<table border="0">
			<tr>
				<th>Type</th>
				<th>Value</th>
			</tr>
			<xsl:for-each select="HEADER_INFO_TABLE/IHTTPNVP">
				<tr>
					<td><xsl:value-of select="NAME"/></td>
					<td><xsl:value-of select="VALUE"/></td>
				</tr>
			</xsl:for-each>
		</table>
	</xsl:template>
</xsl:stylesheet>
