<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:asx="http://www.sap.com/abapxml">

  <xsl:output method="html"/>

  <xsl:template match="/">
    <html>
      <head>
        <title>SAP Readiness Check</title>
        <link rel="stylesheet" type="text/css" href="fui-site.css"/>
      </head>
      <body>
            <article class="fd-page">
              <header class="fd-page__header">
                <div class="fd-action-bar">
                  <div class="fd-action-bar__header">
                    <h1 class="fd-action-bar__title">
                      SAP Readiness Check - relevant simplification items
                    </h1>

                  </div>

                </div>
                <p class="fd-action-bar__description">

                   The <b>sitem_relevance.xml</b> collects a list of SAP S/4HANA
                   simplification items with their relevancy.

                 </p>


                 <table class="fd-table">
                   <tr>
                     <th>Key</th>
                     <th>Value</th>
                   </tr>



                   <tr>
                     <td>Selected S/4HANA stack</td>
                     <td><xsl:value-of select="/asx:abap/asx:values/CONVERSION_TARGET_STACK"/></td>
                   </tr>
                     <tr>
                       <td>Start time</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/START_TIME_UTC"/></td>
                     </tr>
                     <tr>
                       <td>Start time (with time zone)</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/START_TIME_WH_TIMEZONE"/></td>
                     </tr>
                     <tr>
                       <td>End time</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/END_TIME_UTC"/></td>
                     </tr>
                     <tr>
                       <td>End time (with time zone)</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/END_TIME_WH_TIMEZONE"/></td>
                     </tr>
                     <tr>
                       <td>Runtime in seconds</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/RUNNING_TIME_IN_SECONDS"/></td>
                     </tr>
                     <tr>
                       <td>System ID</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/SYSTEM_NAME"/></td>
                     </tr>
                     <tr>
                       <td>System client</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/SYSTEM_CLIENT"/></td>
                     </tr>
                     <tr>
                       <td>Simplification item content version</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/SIMP_ITEM_CAT_VER_UTC"/></td>
                     </tr>
                     <tr>
                       <td>Is ST03 data sufficient</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/NO_ENOUGH_ST03_DATA"/></td>
                     </tr>
                     <tr>
                       <td>SAP Note number</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/FWK_NOTE_NUMBER"/></td>
                     </tr>
                     <tr>
                       <td>Implemented version</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/FWK_NOTE_CURRENT_VER"/></td>
                     </tr>
                     <tr>
                       <td>Minimal required version</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/FWK_NOTE_MIN_REQ_VER"/></td>
                     </tr>
                     <tr>
                       <td>Is the implemented note updated</td>
                       <td><xsl:value-of select="/asx:abap/asx:values/SITEM_RELE_CHK_HDR_INFO/FWK_NOTE_LATEST_IMPLED"/></td>
                     </tr>

                 </table>

                 <table class="fd-table">
                   <tr>
                     <th>Simplification Item Guid</th>
                     <th>Applicable</th>
                     <th>Applicable status</th>
                     <th>Category</th>
                     <th>Relevance status</th>
                     <th>Relevance</th>
                     <th>Summary</th>
                     <th>Technical summary</th>
                     <th>SQL statement</th>
                   </tr>

                   <xsl:for-each select="/asx:abap/asx:values/SITEM_RELE_CHECK_RESULT/item">

                     <tr>
                       <td><xsl:value-of select="SITEM_GUID"/></td>
                       <td><xsl:value-of select="APPLICABLE"/></td>
                       <td><xsl:value-of select="APPLICABLE_STAT"/></td>
                       <td><xsl:value-of select="MATCH_TARGET_REL_CATEGORY"/></td>
                       <td><xsl:value-of select="RELEVANT_STAT"/></td>
                       <td><xsl:value-of select="RELEVANT_STAT_INT"/></td>
                       <td><xsl:value-of select="SUMMARY"/></td>
                       <td><xsl:value-of select="SUMMARY_INT"/></td>
                       <td><xsl:value-of select="SQL_STR_INT"/></td>
                     </tr>
                   </xsl:for-each>

                 </table>

              </header>
            </article>


      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
